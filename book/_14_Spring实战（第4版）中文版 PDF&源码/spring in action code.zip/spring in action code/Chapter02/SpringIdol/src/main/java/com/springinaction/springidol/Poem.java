package com.springinaction.springidol;

public interface Poem {
  public void recite();
}
