package com.springinaction.springidol;

public interface TalentCompetition {
  public void run();
}
