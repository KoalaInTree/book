package com.springinaction.springidol;

public interface Performer {
  public void perform() throws PerformanceException;
}
