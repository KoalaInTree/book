package com.springinaction.springidol;

public class Saxophone implements Instrument {
  public Saxophone() {}
  
  public void play() {
    System.out.println("TOOT TOOT TOOT");
  }
}
