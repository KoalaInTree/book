package com.springinaction.springidol;

public interface Instrument {
  public void play();
}
