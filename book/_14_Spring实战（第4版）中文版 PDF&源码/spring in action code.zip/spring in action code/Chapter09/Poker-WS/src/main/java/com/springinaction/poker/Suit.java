package com.springinaction.poker;

public enum Suit {
  SPADES, CLUBS, HEARTS, DIAMONDS
}
