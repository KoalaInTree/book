package com.roadrantz.marketing;

import com.roadrantz.domain.Motorist;

public interface RantzMarketingGateway {
  public void sendMotoristInfo(Motorist driver);
}
