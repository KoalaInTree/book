package com.roadrantz.service;

public class MotoristAlreadyExistsException extends Exception {
  public MotoristAlreadyExistsException() {}
}
