package com.roadrantz.service.mbean;

import java.util.Date;

public interface ManagedRantService {
  public void sendDailyRantEmails();
}
