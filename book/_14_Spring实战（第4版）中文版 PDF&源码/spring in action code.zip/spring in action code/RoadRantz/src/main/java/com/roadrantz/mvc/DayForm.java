package com.roadrantz.mvc;

import java.util.Date;

public class DayForm {
  private Date day;
  public DayForm() {}

  public Date getDay() {
    return day;
  }
  
  public void setDay(Date day) {
    this.day = day;
  }
}
