package com.roadrantz.service.mbean;

public interface RantServiceRemoteMBean {
  public void sendDailyRantEmails();
}
