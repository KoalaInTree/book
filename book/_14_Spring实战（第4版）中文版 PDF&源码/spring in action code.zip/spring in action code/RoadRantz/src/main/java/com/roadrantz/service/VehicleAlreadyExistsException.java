package com.roadrantz.service;

public class VehicleAlreadyExistsException extends Exception {
  public VehicleAlreadyExistsException() {}
}
