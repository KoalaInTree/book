package com.roadrantz.marketing;

public interface MarketingService {
  public void processDriverInfo(SpammedMotorist driver);
}
