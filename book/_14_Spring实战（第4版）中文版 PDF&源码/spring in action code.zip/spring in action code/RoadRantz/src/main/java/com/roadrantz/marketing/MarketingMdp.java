package com.roadrantz.marketing;

/**
 * Marketing message-driven POJO, as it appears in listing 10.9.
 * 
 * @author wallsc
 */
public class MarketingMdp implements MarketingService {
   public MarketingMdp() {}

   public void processDriverInfo(SpammedMotorist driver) {}
}
