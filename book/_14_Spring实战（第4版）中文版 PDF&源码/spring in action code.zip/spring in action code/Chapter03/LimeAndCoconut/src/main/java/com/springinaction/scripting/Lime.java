package com.springinaction.scripting;

public interface Lime {
  public void drink();
}
