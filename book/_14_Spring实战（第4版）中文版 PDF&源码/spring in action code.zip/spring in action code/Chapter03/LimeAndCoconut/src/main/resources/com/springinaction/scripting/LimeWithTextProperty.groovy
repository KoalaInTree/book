class Lime implements com.springinaction.scripting.Lime {
    void drink() {
      print text;
    }
    
    String text;
}

