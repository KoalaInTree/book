class Lime
  def drink
    puts "Called the doctor woke him up!"
  end
end
Lime.new