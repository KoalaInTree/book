class Lime
  def setText(text)
    @text = text
  end

  def drink
    puts @text
  end
end
Lime.new