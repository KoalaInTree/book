package com.springinaction.scripting;

public class LimeImpl implements Lime {
  public LimeImpl() {}
  
  public void drink() {
    System.out.println("Called the doctor woke him up!");
  }
}
