package com.springinaction.scripting;

public interface ICoconut {
  public void drinkThemBothUp();
}
