class Lime implements com.springinaction.scripting.Lime {
    void drink() {
      print "Called the doctor woke him up!"
    }
}

