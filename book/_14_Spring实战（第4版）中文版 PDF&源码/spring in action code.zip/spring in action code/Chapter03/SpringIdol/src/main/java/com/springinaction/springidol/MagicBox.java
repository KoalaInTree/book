package com.springinaction.springidol;

public interface MagicBox {
  public String getContents();
}
