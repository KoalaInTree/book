package com.springinaction.springidol;

public class MagicBoxImpl implements MagicBox {
  public MagicBoxImpl() {}
  
  public String getContents() {
    return "A beautiful assistant";
  }
}
