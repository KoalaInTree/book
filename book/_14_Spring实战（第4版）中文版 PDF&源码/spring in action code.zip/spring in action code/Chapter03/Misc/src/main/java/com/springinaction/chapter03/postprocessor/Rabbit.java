package com.springinaction.chapter03.postprocessor;

public class Rabbit {
  private String description;

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }
}
