package com.springinaction.pizza.domain;

import java.io.Serializable;

public enum Topping implements Serializable {
  PEPPERONI, 
  SAUSAGE, 
  HAMBURGER,
  MUSHROOM, 
  CANADIAN_BACON, 
  PINEAPPLE,
  GREEN_PEPPER,
  JALAPENO,
  TOMATO,
  ONION,
  EXTRA_CHEESE
}
