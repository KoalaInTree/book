package com.springinaction.chapter01.hello;

public interface GreetingService {
  public void sayGreeting();
}
