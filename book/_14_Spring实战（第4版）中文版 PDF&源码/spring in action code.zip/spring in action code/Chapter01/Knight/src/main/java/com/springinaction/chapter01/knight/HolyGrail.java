package com.springinaction.chapter01.knight;


public class HolyGrail {
  public HolyGrail() {}
  
  public boolean isHoly() {
    return true;
  }
}
