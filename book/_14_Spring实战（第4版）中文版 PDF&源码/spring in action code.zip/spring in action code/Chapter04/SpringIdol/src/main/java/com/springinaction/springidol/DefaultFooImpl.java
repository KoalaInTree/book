package com.springinaction.springidol;

public class DefaultFooImpl implements Foo {
  public DefaultFooImpl() {}
  
  public void doSomething() {
    System.out.println("DEFAULT FOO IMPL: DOING SOMETHING!!!");
  }
}
