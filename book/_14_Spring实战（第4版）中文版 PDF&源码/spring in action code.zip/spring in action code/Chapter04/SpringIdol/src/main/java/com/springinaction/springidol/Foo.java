package com.springinaction.springidol;

public interface Foo {
  public void doSomething();
}
