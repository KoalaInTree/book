package com.springinaction.springidol;

public interface CriticismEngine {
  public String getCriticism();
}
